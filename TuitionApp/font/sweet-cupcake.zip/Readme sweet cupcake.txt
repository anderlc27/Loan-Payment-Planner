Hello,

Thank for downloading Sweet Cupcake .


NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 


Paypal account for donation : https://www.paypal.me/mlkwsn

Link to purchase full version and commercial license:https://fontbundles.net/mlkwsnstudio/125377-sweet-cupcake


Please visit our store for more great fonts : https://creativemarket.com/mlkwsn999




If there is a problem, question, or anything about my fonts, please sent an email to

mlkwsn999@gmail.com




Thanks,

MLKWSN Studios